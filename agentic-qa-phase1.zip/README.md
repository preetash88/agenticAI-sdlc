# Agentic QA Platform — Phase 1

A deliberately small MVP for an agentic QA workflow using LangGraph + MCP.

## Phase 1 architecture

```text
User
  |
  v
LangGraph
  |
  +--> Jira Agent ------> Jira MCP (local mock)
  |
  +--> Strategy Agent --> Quip MCP (local mock)
  |
  +--> TestRail Agent --> TestRail MCP (local mock)
```

The MCP servers are real FastMCP servers. Their backends are local JSON files so no Jira, Quip or TestRail credentials are required.

Later, the Jira node can consume Atlassian's official remote Rovo MCP, while our Quip/TestRail servers can be changed to call their real APIs.

## Prerequisites

- Python 3.11+
- Ollama installed and running
- `qwen3:8b` available locally

## Setup (PowerShell)

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip
pip install -e ".[dev]"
ollama pull qwen3:8b
Copy-Item .env.example .env
```

## Run tests

```powershell
pytest
```

## Run Phase 1

```powershell
python -m app.main
```

Example input:

```text
Feature name:
User Login

Detailed feature / automation steps:
Navigate to the login page. Enter a valid username and password. Click Login. Verify that the dashboard is displayed.
```

## What happens

1. Jira agent creates `QA-1` and transitions it to `In Progress`.
2. Strategy agent asks the local LLM for a structured strategy and stores it through Quip MCP.
3. TestRail agent creates two initial test cases through TestRail MCP.
4. The final state is printed.

## Important architectural boundary

The LangGraph nodes do not directly manipulate Jira/Quip/TestRail storage. They call MCP tools. The MCP servers own the integration boundary.
