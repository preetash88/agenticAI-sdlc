from langchain_ollama import ChatOllama
from pydantic import BaseModel, Field
from app.mcp.client import build_mcp_client
from app.models.state import QAState


class Strategy(BaseModel):
    objective: str
    functional: list[str] = Field(min_length=1)
    negative: list[str] = Field(default_factory=list)
    data: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)


async def strategy_agent(state: QAState) -> dict:
    llm = ChatOllama(model="qwen3:8b", temperature=0)
    structured = llm.with_structured_output(Strategy)
    result = await structured.ainvoke(
        "Create a concise QA test strategy for this feature.\n"
        f"Feature: {state['feature_name']}\n"
        f"Requirement: {state['user_prompt']}"
    )

    strategy_text = (
        f"# {state['feature_name']} - Test Strategy\n\n"
        f"## Objective\n{result.objective}\n\n"
        f"## Functional Coverage\n" + "\n".join(f"- {x}" for x in result.functional) + "\n\n"
        f"## Negative Coverage\n" + "\n".join(f"- {x}" for x in result.negative) + "\n\n"
        f"## Test Data\n" + "\n".join(f"- {x}" for x in result.data) + "\n\n"
        f"## Risks\n" + "\n".join(f"- {x}" for x in result.risks)
    )

    client = build_mcp_client()
    tools = await client.get_tools()
    tool_map = {tool.name: tool for tool in tools}
    doc = await tool_map["quip_quip_create_document"].ainvoke({
        "title": f"{state['feature_name']} - Test Strategy",
        "content": strategy_text,
    })

    return {"test_strategy": strategy_text, "quip_document_id": doc["id"]}
