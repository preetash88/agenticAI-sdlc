from app.mcp.client import build_mcp_client
from app.models.state import QAState


async def jira_agent(state: QAState) -> dict:
    client = build_mcp_client()
    tools = await client.get_tools()
    tool_map = {tool.name: tool for tool in tools}

    issue = await tool_map["jira_jira_create_issue"].ainvoke({
        "project_key": state.get("jira_project", "QA"),
        "summary": state["feature_name"],
        "description": state["user_prompt"],
        "status": "To Do",
    })

    issue = await tool_map["jira_jira_transition_issue"].ainvoke({
        "issue_key": issue["key"],
        "status": "In Progress",
    })

    return {
        "jira_issue_key": issue["key"],
        "jira_description": issue["description"],
    }
