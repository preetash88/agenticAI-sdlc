from app.mcp.client import build_mcp_client
from app.models.state import QAState


async def testrail_agent(state: QAState) -> dict:
    # Phase 1 deliberately uses a deterministic generator.
    # Later this node becomes an LLM planner with structured output + RAG.
    cases = [
        {
            "title": f"{state['feature_name']} - happy path",
            "steps": ["Follow the user-provided workflow", "Complete the feature successfully"],
            "expected_result": "The feature completes successfully.",
        },
        {
            "title": f"{state['feature_name']} - invalid input",
            "steps": ["Follow the workflow with invalid input"],
            "expected_result": "The application displays an appropriate validation error.",
        },
    ]

    client = build_mcp_client()
    tools = await client.get_tools()
    tool_map = {tool.name: tool for tool in tools}

    created = []
    for case in cases:
        result = await tool_map["testrail_testrail_create_case"].ainvoke({
            "project_id": 1,
            **case,
        })
        created.append(result)

    return {"test_cases": created, "testrail_project_id": 1}
