import asyncio
import json
from app.graph.workflow import build_graph


async def main():
    feature = input("Feature name: ").strip()
    prompt = input("Detailed feature / automation steps: ").strip()

    graph = build_graph()
    result = await graph.ainvoke({
        "feature_name": feature,
        "user_prompt": prompt,
        "jira_project": "QA",
        "errors": [],
    })

    print("\n=== PHASE 1 RESULT ===")
    print(json.dumps({
        "jira_issue_key": result.get("jira_issue_key"),
        "quip_document_id": result.get("quip_document_id"),
        "testrail_project_id": result.get("testrail_project_id"),
        "test_case_count": len(result.get("test_cases", [])),
    }, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
