from fastmcp import FastMCP
from app.mcp.storage import load, save

mcp = FastMCP("TestRail Mock MCP")


@mcp.tool
def testrail_create_case(
    project_id: int,
    title: str,
    steps: list[str],
    expected_result: str,
) -> dict:
    data = load("testrail.json")
    if not any(p["id"] == project_id for p in data["projects"]):
        raise ValueError(f"Unknown TestRail project: {project_id}")

    case_id = len(data["cases"]) + 1
    case = {
        "id": case_id,
        "project_id": project_id,
        "title": title,
        "steps": steps,
        "expected_result": expected_result,
    }
    data["cases"].append(case)
    save("testrail.json", data)
    return case


@mcp.tool
def testrail_list_cases(project_id: int) -> list[dict]:
    data = load("testrail.json")
    return [c for c in data["cases"] if c["project_id"] == project_id]


if __name__ == "__main__":
    mcp.run()
