import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT / "mock_data"


def load(name: str) -> dict[str, Any]:
    path = DATA_DIR / name
    return json.loads(path.read_text(encoding="utf-8"))


def save(name: str, data: dict[str, Any]) -> None:
    path = DATA_DIR / name
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
