from fastmcp import FastMCP
from app.mcp.storage import load, save

mcp = FastMCP("Jira Mock MCP")


@mcp.tool
def jira_create_issue(project_key: str, summary: str, description: str, status: str = "To Do") -> dict:
    data = load("jira.json")
    project = next((p for p in data["projects"] if p["key"] == project_key), None)
    if not project:
        raise ValueError(f"Unknown Jira project: {project_key}")

    number = len(data["issues"]) + 1
    key = f"{project_key}-{number}"
    issue = {
        "key": key,
        "project": project_key,
        "summary": summary,
        "description": description,
        "status": status,
    }
    data["issues"].append(issue)
    save("jira.json", data)
    return issue


@mcp.tool
def jira_transition_issue(issue_key: str, status: str) -> dict:
    data = load("jira.json")
    for issue in data["issues"]:
        if issue["key"] == issue_key:
            issue["status"] = status
            save("jira.json", data)
            return issue
    raise ValueError(f"Jira issue not found: {issue_key}")


@mcp.tool
def jira_get_issue(issue_key: str) -> dict:
    data = load("jira.json")
    for issue in data["issues"]:
        if issue["key"] == issue_key:
            return issue
    raise ValueError(f"Jira issue not found: {issue_key}")


if __name__ == "__main__":
    mcp.run()
