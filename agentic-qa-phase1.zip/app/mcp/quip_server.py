from fastmcp import FastMCP
from app.mcp.storage import load, save

mcp = FastMCP("Quip Mock MCP")


@mcp.tool
def quip_create_document(title: str, content: str) -> dict:
    data = load("quip.json")
    document_id = f"QUIP-{len(data['documents']) + 1}"
    document = {"id": document_id, "title": title, "content": content}
    data["documents"].append(document)
    save("quip.json", data)
    return document


@mcp.tool
def quip_get_document(document_id: str) -> dict:
    data = load("quip.json")
    for document in data["documents"]:
        if document["id"] == document_id:
            return document
    raise ValueError(f"Quip document not found: {document_id}")


if __name__ == "__main__":
    mcp.run()
