from pathlib import Path
from langchain_mcp_adapters.client import MultiServerMCPClient

ROOT = Path(__file__).resolve().parents[2]


def build_mcp_client() -> MultiServerMCPClient:
    return MultiServerMCPClient({
        "jira": {
            "transport": "stdio",
            "command": "python",
            "args": ["-m", "app.mcp.jira_server"],
        },
        "quip": {
            "transport": "stdio",
            "command": "python",
            "args": ["-m", "app.mcp.quip_server"],
        },
        "testrail": {
            "transport": "stdio",
            "command": "python",
            "args": ["-m", "app.mcp.testrail_server"],
        },
    })
