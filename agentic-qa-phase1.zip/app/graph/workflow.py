from langgraph.graph import StateGraph, START, END
from app.models.state import QAState
from app.agents.jira_agent import jira_agent
from app.agents.strategy_agent import strategy_agent
from app.agents.testrail_agent import testrail_agent


def build_graph():
    graph = StateGraph(QAState)
    graph.add_node("jira_agent", jira_agent)
    graph.add_node("strategy_agent", strategy_agent)
    graph.add_node("testrail_agent", testrail_agent)

    graph.add_edge(START, "jira_agent")
    graph.add_edge("jira_agent", "strategy_agent")
    graph.add_edge("strategy_agent", "testrail_agent")
    graph.add_edge("testrail_agent", END)

    return graph.compile()
