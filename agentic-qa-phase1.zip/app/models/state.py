from typing import TypedDict, Any


class QAState(TypedDict, total=False):
    feature_name: str
    user_prompt: str
    jira_project: str
    jira_issue_key: str
    jira_description: str
    test_strategy: str
    quip_document_id: str
    test_cases: list[dict[str, Any]]
    testrail_project_id: int
    errors: list[str]
