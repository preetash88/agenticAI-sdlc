from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]


def test_mock_data_files_exist():
    for name in ["jira.json", "quip.json", "testrail.json"]:
        assert (ROOT / "mock_data" / name).exists()
        json.loads((ROOT / "mock_data" / name).read_text())
